const { PrismaClient } = require('@prisma/client')
const prisma = new PrismaClient()

async function main() {
  await prisma.title.createMany({
    data: [
      { type: 'anime', slug: 'tsukikage', title: 'Tsukikage', synopsis: 'Demo Tsukikage giriş', rating: 9.0 },
      { type: 'anime', slug: 'mystic-saga', title: 'Mystic Saga', synopsis: 'Aksiyon macera demo', rating: 8.4 },
      { type: 'manga', slug: 'blooming-hearts', title: 'Blooming Hearts', synopsis: 'Romantik manga demo', rating: 7.9 }
    ]
  })
  console.log('Seed tamamlandı.')
}

main()
  .catch(e => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
