export default function handler(req, res) {
  const list = Array.from({ length: 12 }).map((_, i) => ({
    id: i+1,
    title: `Anime ${i+1}`,
    slug: `anime-${i+1}`,
    rating: +(7 + Math.random()).toFixed(1)
  }))
  res.status(200).json({ data: list })
}
