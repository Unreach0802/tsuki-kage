import React, { useState } from 'react'
import Sidebar from './components/Sidebar'
import Header from './components/Header'
import Hero from './components/Hero'
import AnimeCard from './components/AnimeCard'

const sample = Array.from({ length: 8 }).map((_, i) => ({ id: i+1, title: `Anime ${i+1}`, rating: (8 + Math.random()).toFixed(1) }))

export default function Page() {
  const [open, setOpen] = useState(false)
  return (
    <div>
      <Sidebar />
      <Header onToggle={() => setOpen(!open)} />

      <main className="ml-0 md:ml-72 p-4">
        <Hero featured={[{id:1,title:'Tsukikage',subtitle:'En Yeni Anime ve Manga'}]} />

        <section className="p-8">
          <div className="flex items-center gap-3 mb-6">
            <button className="px-4 py-2 rounded-full bg-violet-600">Ana Sayfa</button>
            <button className="px-4 py-2 rounded-full bg-white/5">Anime</button>
            <button className="px-4 py-2 rounded-full bg-white/5">Manga</button>
            <button className="px-4 py-2 rounded-full bg-white/5">Kategoriler</button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {sample.map(it => (
              <AnimeCard key={it.id} item={it} />
            ))}
          </div>
        </section>
      </main>
    </div>
  )
}
