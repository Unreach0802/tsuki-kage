import React from 'react'

export default function Sidebar() {
  return (
    <aside className="w-72 bg-slate-900 border-r border-slate-800 h-screen fixed p-4 hidden md:block">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center text-xl font-bold">T</div>
        <div>
          <div className="font-semibold">Tsukikage</div>
          <div className="text-xs text-slate-400">En Yeni Anime ve Manga</div>
        </div>
      </div>

      <nav className="space-y-2 text-sm">
        <a className="block px-3 py-2 rounded-md bg-purple-700/20">Anasayfa</a>
        <a className="block px-3 py-2 rounded-md hover:bg-white/5">Uygulamalar</a>
        <a className="block px-3 py-2 rounded-md hover:bg-white/5">Keşfet</a>
        <a className="block px-3 py-2 rounded-md hover:bg-white/5">Trendler</a>
        <a className="block px-3 py-2 rounded-md hover:bg-white/5">Takvim</a>
        <a className="block px-3 py-2 rounded-md hover:bg-white/5">Animeler</a>
        <a className="block px-3 py-2 rounded-md hover:bg-white/5">Manga</a>
        <a className="block px-3 py-2 rounded-md hover:bg-white/5">İstek Listesi</a>
      </nav>

      <div className="absolute bottom-6 left-4 right-4">
        <div className="flex items-center gap-3 bg-slate-800/60 p-3 rounded-lg">
          <div className="w-10 h-10 rounded-full bg-indigo-500 flex items-center justify-center">L</div>
          <div className="flex-1">
            <div className="text-sm font-medium">Lusi</div>
            <div className="text-xs text-slate-400">Rahatsız Etmeyin</div>
          </div>
          <button className="px-3 py-1 bg-amber-400 text-black rounded-full text-xs">Premium</button>
        </div>
      </div>
    </aside>
  )
}
