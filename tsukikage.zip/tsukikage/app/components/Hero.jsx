import React from 'react'

export default function Hero({ featured=[] }) {
  return (
    <section className="p-8">
      <div className="rounded-2xl bg-gradient-to-tr from-slate-900/80 to-violet-900/40 p-8 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
          <div>
            <h1 className="text-4xl md:text-5xl font-extrabold">Tsukikage</h1>
            <p className="mt-2 text-slate-300 max-w-xl">En Yeni Anime ve Manga — favori serilerinizi keşfedin, izleme listelerinizi yönetin.</p>

            <div className="mt-6 flex items-center gap-3">
              <button className="px-5 py-2 rounded-full bg-violet-600 font-semibold">Hemen İzle</button>
              <button className="px-4 py-2 rounded-full bg-white/5">Discord</button>
              <button className="px-4 py-2 rounded-full bg-pink-600">Instagram</button>
              <button className="px-4 py-2 rounded-full bg-black/30">TikTok</button>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            {featured.map(f => (
              <div key={f.id} className="w-40 h-24 rounded-lg bg-gradient-to-br from-slate-800 to-slate-700 p-3 flex flex-col justify-between">
                <div className="text-sm font-semibold">{f.title}</div>
                <div className="text-xs text-slate-400">{f.subtitle}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="pointer-events-none absolute right-6 top-6 opacity-20">❄️ ❄️ ❄️</div>
      </div>
    </section>
  )
}
