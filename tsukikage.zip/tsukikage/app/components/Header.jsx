import React from 'react'

export default function Header({ onToggle }) {
  return (
    <header className="flex items-center justify-between p-4 border-b border-slate-800 ml-0 md:ml-72">
      <div className="flex items-center gap-3">
        <button className="md:hidden p-2 rounded-md bg-white/5" onClick={onToggle} aria-label="toggle menu">☰</button>
        <div className="text-2xl font-bold neon">Tsukikage</div>
        <div className="hidden md:block ml-6 bg-slate-800/40 rounded-full px-3 py-1 text-slate-300"> <input placeholder="Anime, manga ara..." className="bg-transparent outline-none text-sm" /></div>
      </div>

      <div className="flex items-center gap-4">
        <button className="px-4 py-2 rounded-full bg-violet-500 hover:brightness-110">Premium</button>
        <div className="w-9 h-9 rounded-full bg-pink-500" />
      </div>
    </header>
  )
}
