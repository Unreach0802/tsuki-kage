import React from 'react'

export default function AnimeCard({ item }) {
  return (
    <article className="bg-slate-800/40 rounded-lg overflow-hidden">
      <div className="h-40 bg-gradient-to-b from-indigo-700 to-slate-800 flex items-end p-3">
        <div className="text-white font-semibold">{item.title}</div>
      </div>
      <div className="p-3">
        <div className="text-sm text-slate-300">Tür: {item.genres || 'Aksiyon · Fantastik'}</div>
        <div className="mt-3 flex items-center justify-between">
          <button className="px-3 py-1 rounded-full bg-violet-600 text-sm">İzle</button>
          <div className="text-xs text-slate-400">{item.rating ?? '—'}</div>
        </div>
      </div>
    </article>
  )
}
