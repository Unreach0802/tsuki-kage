import '../styles/globals.css'

export const metadata = {
  title: 'Tsukikage',
  description: 'En yeni anime ve manga platformu'
}

export default function RootLayout({ children }) {
  return (
    <html lang="tr">
      <body>
        {children}
      </body>
    </html>
  )
}
